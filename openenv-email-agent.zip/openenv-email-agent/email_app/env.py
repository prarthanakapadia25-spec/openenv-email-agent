from app.models import Email


class EmailEnv:
    def __init__(self):
        self.state_data = []
        self.done = False

    def reset(self):
        self.state_data = [
            Email(subject="Meeting Tomorrow", body="Please confirm your availability."),
            Email(subject="Win Lottery!!!", body="Click this link to claim prize"),
            Email(subject="Project Update", body="Send latest report.")
        ]
        self.done = False
        return self._get_state()

    def step(self, action):
        reward = 0.0

      
        email_index = action.get("email_index")
        action_type = action.get("action_type")

        if email_index is not None and email_index < len(self.state_data):
            email = self.state_data[email_index]

            if action_type == "delete" and "Lottery" in email.subject:
                reward += 1.0
            elif action_type == "reply" and "Meeting" in email.subject:
                reward += 0.8
            else:
                reward -= 0.2

        self.done = True

        return {
            "observation": self._get_state(),
            "reward": reward,
            "done": self.done
        }

    def state(self):
        return self._get_state()

    def _get_state(self):
        return {
            "inbox": [
                {"subject": email.subject, "body": email.body}
                for email in self.state_data
            ],
            "done": self.done
        }