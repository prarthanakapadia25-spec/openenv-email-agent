from pydantic import BaseModel
from typing import List, Dict


class Email(BaseModel):
    subject: str
    body: str


class GradeRequest(BaseModel):
    actions: List[Dict]