TASKS = [
    {"id": "task_easy", "difficulty": "easy"},
    {"id": "task_medium", "difficulty": "medium"},
    {"id": "task_hard", "difficulty": "hard"}
]