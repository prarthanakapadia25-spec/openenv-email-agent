def grade(task_name, actions):
    score = 0.0

    for action in actions:
        if action.get("action_type") == "delete":
            score += 0.5
        elif action.get("action_type") == "reply":
            score += 0.5

    return min(score / len(actions), 1.0) if actions else 0.0