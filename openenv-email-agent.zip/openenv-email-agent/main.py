from fastapi import FastAPI
from app.env import EmailEnv
from app.models import GradeRequest
from app.grader import grade
from app.tasks import TASKS

app = FastAPI()
env = EmailEnv()


@app.get("/")
def home():
    return {"message": "Email Agent Environment is running", "docs": "/docs"}


@app.post("/reset")
def reset():
    return env.reset()


@app.post("/step")
def step(action: dict):   # ✅ IMPORTANT FIX
    return env.step(action)


@app.get("/state")
def state():
    return env.state()


@app.get("/tasks")
def get_tasks():
    return {"tasks": TASKS}


@app.post("/grader")
def run_grader(task_name: str, body: GradeRequest):
    return {"score": grade(task_name, body.actions)}